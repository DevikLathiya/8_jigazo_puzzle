package com.example.jigazo_puzzle_7

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
